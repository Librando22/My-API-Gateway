<?php
$valid_api_keys = [
    "key123" => "UserA",
    "key456" => "UserB"
];

$headers = getallheaders();
$api_key = $headers['X-API-Key'] ?? null;

if (!$api_key || !array_key_exists($api_key, $valid_api_keys)) {
    http_response_code(401);
    echo json_encode(["error" => "Invalid or missing API Key"]);
    exit;
}

$rate_limit_dir = 'ratelimit_data/';
if (!is_dir($rate_limit_dir)) {
    mkdir($rate_limit_dir, 0777, true);
}

$rate_file = $rate_limit_dir . $api_key . '.json';

if (file_exists($rate_file)) {
    $data = json_decode(file_get_contents($rate_file), true);
} else {
    $data = ["timestamp" => time(), "count" => 0];
}

$current_time = time();

if (($current_time - $data['timestamp']) > 60) {
    
    $data['timestamp'] = $current_time;
    $data['count'] = 1;
} else {
    if ($data['count'] >= 10) {
        http_response_code(429);
        echo json_encode(["error" => "Rate limit exceeded"]);
        exit;
    }
    $data['count']++;
}

file_put_contents($rate_file, json_encode($data));
function log_request($api_key, $status_code) {
    $log_dir = 'logs/';
    if (!is_dir($log_dir)) {
        mkdir($log_dir, 0777, true);
    }
    $log_file = $log_dir . 'gateway.log';

    $entry = sprintf(
        "[%s] - IP: %s - API Key: %s - Path: %s - Status: %d\n",
        date('Y-m-d H:i:s'),
        $_SERVER['REMOTE_ADDR'],
        $api_key ?: 'None',
        $_GET['request_path'] ?? 'None',
        $status_code
    );

    file_put_contents($log_file, $entry, FILE_APPEND);
}

log_request($api_key ?? 'None', http_response_code());